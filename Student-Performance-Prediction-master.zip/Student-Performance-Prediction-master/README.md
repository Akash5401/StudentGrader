The goal of this project was to predict the future score of students based on their historic performance data. 

A predictive model was built using regression algorithms (Linear & Logistic regression algorithms) that had 85% accuracy. Much emphasis was placed on handling missing values as well as outliers in the data set. 

This project was submitted in a Kaggle competition.
